package com.example.studente.subnetting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Subnetting_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subnetting_main);

        EditText ip1= findViewById( R.id.editText);
        EditText ip2=findViewById(R.id.editText2);
        EditText ip3=findViewById(R.id.editText3);
        EditText ip4=findViewById(R.id.editText4);

        this.InitializeTextchange(ip1);
        this.InitializeTextchange(ip2);
        this.InitializeTextchange(ip3);
        this.InitializeTextchange(ip4);

    }

    private void InitializeTextchange(EditText ip)
    {
        ip.addTextChangedListener(new TextWatcher() {

            // onTextChanged
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                TextView text = (TextView)getCurrentFocus();

                if (text != null && text.length() > 2)
                {
                    View next = text.focusSearch(View.FOCUS_RIGHT); // or FOCUS_FORWARD
                    if (next != null)
                        next.requestFocus();
                }
            }

            // afterTextChanged
            @Override
            public void afterTextChanged(Editable s) {}

            // beforeTextChanged
            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {}
        });
    }
}
